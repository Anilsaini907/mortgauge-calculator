<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Styles -->
        <style>
            input{
              margin-left:30px;
              
            }

           

            #calcWrapper{
              text-align:center;
              margin: auto 0;
            }
        </style>
    </head>
    <body>
  <div id="calcWrapper">
<div class="formDiv">
<h1 sytle="text-aline:center">Mortgage  Calculator</h1>
<form action="">
<label>Loan Amount:<input type="text" id="amt" name="amt"/></lablel><br><br>
<label>Down Payment:<input type="text" id="dwamt" name="dwamt"/></lablel><br><br>
  <label>Rate of Interest %: <input type="text" id="apr" name="APR"/></label><br><br>
  <label>Loan Term (Years): <input type="text" id="trm" name="APR"/></label><br><br>
  
  <input type="button" class="btn btn-success" id="sbt" value="Submit" />
  <input type="reset" class="btn btn-info" id="rst" value="Reset Form" /><br><br>
  <label>Monthly Payment in Rs:<div  ><h2 id="pmt" name="mPmt"></h2> </div></lablel>
</form>

</div>
</div>
<script>

var term;
var apr;
var amt;
var dwamt;
var mPmt;


window.onload = function()
{
  document.getElementById("apr").focus();
  document.getElementById("sbt").onclick = getValues;
};


function getValues()
{
  term = document.getElementById("trm").value;
  apr = document.getElementById("apr").value;
  amt = document.getElementById("amt").value;
  dwamt = document.getElementById("dwamt").value;

  remamt= amt-dwamt;
  apr /= 1200;
  term *= 12;
  mPmt = calculatePayment();
  document.getElementById("pmt").innerText = "INR:-" + mPmt.toFixed(2) + " Rs. per month";
};

function calculatePayment()
{
	var payment = remamt*(apr * Math.pow((1 + apr), term))/(Math.pow((1 + apr), term) - 1);
	return payment;
}
</script>
</body>
</html>
